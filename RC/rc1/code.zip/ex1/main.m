clearvars;

fileIn = 'input.txt';
fileOut = 'output.txt';

findWord(fileIn, fileOut);