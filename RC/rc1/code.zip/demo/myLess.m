function result = myLess(x, y)

	if x >= y
		result = 1;
	else
		result = 0;
	end
	
end
		
		
