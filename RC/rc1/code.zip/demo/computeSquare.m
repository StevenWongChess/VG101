function y = computeSquare(x)

	y = x.^2;
	
end
