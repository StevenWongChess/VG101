#include <stdio.h>
#include <math.h>

int main() {

	printf("%g\n", sqrt(cosh(M_PI / 2)));

}