#include <stdio.h>

int main() {

	int a = 7 / 3;
	printf("%d %f\n", 7 / 3, 7 / 3);
	// printf("%d %f\n", 7 / 3, (double)(7 / 3));
	printf("%d %f\n", 7 / 3, 7.0 / 3);

	return 0;

}