#include <stdlib.h>
#include <stdio.h>

int main() {

	{
		int a = 0;
		printf("%d\n", a);
	}
	{
		double a = 1.124;
		printf("%f\n", a);
	}
	{
		char a = 'a';
		printf("%c\n", a);
	}

}