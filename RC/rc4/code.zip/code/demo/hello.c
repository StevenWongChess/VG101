#include <stdio.h>

void greet() {

	printf("Hello, world!\n");

}

int main() {

	greet();

	return 0;

}