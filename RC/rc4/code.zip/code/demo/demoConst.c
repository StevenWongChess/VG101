#include <stdio.h>

int main() {

	const int a;

	printf("%d\n", a);

	// a = 1;

	return 0;

}