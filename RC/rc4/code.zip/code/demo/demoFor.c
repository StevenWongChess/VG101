#include <stdio.h>

int main() {

	for (int i = 0; i < 10; i++) {
		printf("%d\n", i);
	}

	printf("%d\n", i);

	return 0;

}